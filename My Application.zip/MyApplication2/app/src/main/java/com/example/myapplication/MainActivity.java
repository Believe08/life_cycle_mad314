package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private static String Tag="MainActivity-LifeCycle";

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(Tag,"On start");
    }


    @Override
    protected void onResume() {
        super.onResume();
        Log.i(Tag,"On Resume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(Tag,"On Pause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(Tag,"On Stop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(Tag,"On Destroy");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button myButton = findViewById(R.id.button);
        Log.i(Tag, "On Create");

        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(
                        MainActivity.this,
                        Activity2.class
                );
                Log.i(Tag,"Signing in to new page!!");
                startActivity(intent);
            }
        });









        /*final Button button2 = findViewById(R.id.button2);
        button2.setBackgroundColor(Color.GREEN);

        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int color = ( (ColorDrawable)button2.getBackground()).getColor();
                if(color == Color.GREEN){
                    button2.setBackgroundColor(Color.GREEN);
                }
                else{
                    button2.setBackgroundColor(Color.RED);
                }
            }
        });*/
    }


}
