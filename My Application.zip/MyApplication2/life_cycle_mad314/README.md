# life_cycle_mad314
A small project in class
